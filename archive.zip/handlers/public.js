module.exports = {
  directory: {
    path: 'public'
  }
}
